  var myApp = new Framework7(); 
 
  // Init slider and store its instance in mySwiper variable
  var mySwiper = myApp.swiper('.swiper-container', {
    pagination:'.swiper-pagination'
  });
// Initialize your app
var myApp = new Framework7({
    animateNavBackIcon:true
});

// Export selectors engine
var $$ = Dom7;

// Add main View
var mainView = myApp.addView('.view-main', {
    // Enable dynamic Navbar
    dynamicNavbar: true,
    // Enable Dom Cache so we can use all inline pages
    domCache: true

 });
var myApp = new Framework7(); 
 
var $$ = Dom7;
 
var mainView = myApp.addView('.view-main', {
  dynamicNavbar: true
});
 
/*=== Default standalone ===*/


var myPhotoBrowserStand1 = myApp.photoBrowser({
    photos : [
        'img/2.jpg'
   
       
         
    ]
    
            
         
    
});



//Open photo browser on click
$$('.pb-stand1').on('click', function () {
    myPhotoBrowserStand1.open();
});






var myPhotoBrowserStand2 = myApp.photoBrowser({
    photos : [
        'img/ube.jpg',
        'img/3.png'

    ]
});
//Open photo browser on click
$$('.pb-stand2').on('click', function () {
    myPhotoBrowserStand2.open();
});
var myPhotoBrowserStand3 = myApp.photoBrowser({
    photos : [
        'img/4.jpg'
        

    ]
});
//Open photo browser on click
$$('.pb-stand3').on('click', function () {
    myPhotoBrowserStand3.open();
});
var myPhotoBrowserStand3 = myApp.photoBrowser({
    photos : [
        'img/4.jpg'
        

    ]
});
//Open photo browser on click
$$('.pb-stand3').on('click', function () {
    myPhotoBrowserStand3.open();
});

var myPhotoBrowserStand4 = myApp.photoBrowser({
    photos : [
        'img/5.jpg',
        'img/5-1.png'
        

    ]
});
//Open photo browser on click
$$('.pb-stand4').on('click', function () {
    myPhotoBrowserStand4.open();
});

var myPhotoBrowserStand5 = myApp.photoBrowser({
    photos : [
        'img/6.jpg',
        'img/6-1.jpg'
        

    ]
});
//Open photo browser on click
$$('.pb-stand5').on('click', function () {
    myPhotoBrowserStand5.open();
});
var myPhotoBrowserStand6 = myApp.photoBrowser({
    photos : [
        'img/7.jpg',
        'img/7-1.png'
        

    ]
});
//Open photo browser on click
$$('.pb-stand6').on('click', function () {
    myPhotoBrowserStand6.open();
});
var myPhotoBrowserStand7 = myApp.photoBrowser({
    photos : [
        'img/8.jpg',
        'img/8-1.jpg'
        

    ]
});
//Open photo browser on click
$$('.pb-stand7').on('click', function () {
    myPhotoBrowserStand7.open();
});
var myPhotoBrowserStand8 = myApp.photoBrowser({
    photos : [
        'img/9.jpg',
        'img/9-1.jpg'
        

    ]
});
//Open photo browser on click
$$('.pb-stand8').on('click', function () {
    myPhotoBrowserStand8.open();
});
var myPhotoBrowserStand9 = myApp.photoBrowser({
    photos : [
        'img/10.jpg',
        'img/10-1.jpg'
        

    ]
});
//Open photo browser on click
$$('.pb-stand9').on('click', function () {
    myPhotoBrowserStand9.open();
});
var myPhotoBrowserStand10 = myApp.photoBrowser({
    photos : [
        'img/11.jpg',
        'img/11-1.jpg'
        

    ]
});
//Open photo browser on click
$$('.pb-stand10').on('click', function () {
    myPhotoBrowserStand10.open();
});
var myPhotoBrowserStand11 = myApp.photoBrowser({
    photos : [
        'img/12.jpg',
        'img/12-1.jpg',
         'img/12-2.jpg',
          'img/12-3.jpg'
        

    ]
});
//Open photo browser on click
$$('.pb-stand11').on('click', function () {
    myPhotoBrowserStand11.open();
});
var myPhotoBrowserStand12 = myApp.photoBrowser({
    photos : [
        'img/13.jpg',
        'img/13-1.jpg',
         'img/13-2.jpg'
          
        

    ]
});
//Open photo browser on click
$$('.pb-stand12').on('click', function () {
    myPhotoBrowserStand12.open();
});
var myPhotoBrowserStand13 = myApp.photoBrowser({
    photos : [
        'img/14.jpg',
        'img/14-1.png'
         
          
        

    ]
});
//Open photo browser on click
$$('.pb-stand13').on('click', function () {
    myPhotoBrowserStand13.open();
});
var myPhotoBrowserStand14 = myApp.photoBrowser({
    photos : [
        'img/15.jpg',
        'img/15-1.png'
         
          
        

    ]
});
//Open photo browser on click
$$('.pb-stand14').on('click', function () {
    myPhotoBrowserStand14.open();
});
var myPhotoBrowserStand15 = myApp.photoBrowser({
    photos : [
        'img/16.jpg',
        'img/16-1.jpg'
         
          
        

    ]
});
//Open photo browser on click
$$('.pb-stand15').on('click', function () {
    myPhotoBrowserStand15.open();
});
var myPhotoBrowserStand16 = myApp.photoBrowser({
    photos : [
        'img/17.jpg',
        'img/17-1.png'
         
          
        

    ]
});
//Open photo browser on click
$$('.pb-stand16').on('click', function () {
    myPhotoBrowserStand16.open();
});
var myPhotoBrowserStand17 = myApp.photoBrowser({
    photos : [
        'img/18.jpg',
        'img/18-1.png'
         
          
        

    ]
});
//Open photo browser on click
$$('.pb-stand17').on('click', function () {
    myPhotoBrowserStand17.open();
});
var myPhotoBrowserStand18 = myApp.photoBrowser({
    photos : [
        'img/19.jpg',
        'img/19-1.png'
         
          
        

    ]
});
//Open photo browser on click
$$('.pb-stand18').on('click', function () {
    myPhotoBrowserStand18.open();
});
var myPhotoBrowserStand19= myApp.photoBrowser({
    photos : [
        'img/20.jpg',
        'img/20-1.jpg'
         
          
        

    ]
});
//Open photo browser on click
$$('.pb-stand19').on('click', function () {
    myPhotoBrowserStand19.open();
});
var myPhotoBrowserStand20= myApp.photoBrowser({
    photos : [
        'img/21.jpg',
        'img/21-1.png'
         
          
        

    ]
});
//Open photo browser on click
$$('.pb-stand20').on('click', function () {
    myPhotoBrowserStand20.open();
});














